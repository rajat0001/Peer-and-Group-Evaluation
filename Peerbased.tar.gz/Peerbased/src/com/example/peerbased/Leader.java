package com.example.peerbased;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;


public class Leader extends Activity implements OnClickListener 
{

	Button r1,r2;
	ProgressDialog pd1;
	int counter1 = 0;
	Handler h1,h2;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leader);
       
        r1= (Button)findViewById(R.id.button1);
        r2= (Button)findViewById(R.id.button2);
        r1.setOnClickListener(this);
        r1.setOnClickListener(this);
        pd1 = new ProgressDialog(this);
        pd1.setProgress(0);
    
    h1 = new Handler()
    {

		@Override
		public void handleMessage(Message msg) 
		{
			super.handleMessage(msg);
			if(counter1>100)
			{
				pd1.dismiss();
				Intent x = new Intent(getApplicationContext(), leadersconfirm.class);
				startActivity(x);
			}
			else
			{
				counter1++;
				pd1.incrementProgressBy(1);
				h1.sendEmptyMessageDelayed(0, 200);
			}
			
		}
    	
    };
      
    h1 = new Handler()
    {

		@Override
		public void handleMessage(Message msg) 
		{
			super.handleMessage(msg);
			if(counter1>100)
			{
				pd1.dismiss();
				Intent x = new Intent(getApplicationContext(), Chooseleaders.class);
				startActivity(x);
			}
			else
			{
				counter1++;
				pd1.incrementProgressBy(1);
				h1.sendEmptyMessageDelayed(0, 200);
			}
			
		}
    	
    };
    }
	public void onClick(View v) 
	{   
		
		switch (v.getId()) {
		case R.id.button1:
			
			pd1.setTitle("Please Wait for few moments . . . ");
			pd1.setMessage("After this, a new quiz will start.");
			pd1.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			h1.sendEmptyMessage(0);
			pd1.show();
			
			break;
		case R.id.button2:
			
			pd1.setTitle("Please Wait for few moments . . . ");
			pd1.setMessage("After this, a new quiz will start.");
			pd1.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			h2.sendEmptyMessage(0);
			pd1.show();
			
			break;
			
		}
		
		
	}
}
