package com.example.peerbased;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Activity7 extends Activity implements OnClickListener 
{
	Button btn;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.password);
        btn=(Button)findViewById(R.id.button1);
        btn.setOnClickListener(this);
    }
	public void onClick(View v) 
	{   
		Toast.makeText(this, "Password Changed", 1000).show();
		Intent i = new Intent("list_of_options");
		startActivity(i);
		
	}
}
