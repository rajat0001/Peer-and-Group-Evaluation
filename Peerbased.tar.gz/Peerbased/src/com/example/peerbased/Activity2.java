package com.example.peerbased;



import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnMultiChoiceClickListener;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


public class Activity2 extends Activity implements   android.view.View.OnClickListener 
{

	ImageView r1,r2,r3,r4,r5;
	String Performance[] = {"Your individual Performance", "Your Overall Performance"};
	TextView text,display;
	ProgressDialog pd1;
	int counter1 = 0;
	Handler h1;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.optionstudent);
        
        r1 = (ImageView)findViewById(R.id.image1);
        r2 = (ImageView)findViewById(R.id.image2);
        r3 = (ImageView)findViewById(R.id.image3);
        r4 = (ImageView)findViewById(R.id.image4);
        r5 = (ImageView)findViewById(R.id.image5);
        r1.setOnClickListener(this);
        r2.setOnClickListener(this);
        r3.setOnClickListener(this);
        r4.setOnClickListener(this);
        r5.setOnClickListener(this);
        pd1 = new ProgressDialog(this);
        pd1.setProgress(0);
    
    h1 = new Handler()
    {

		@Override
		public void handleMessage(Message msg) 
		{
			super.handleMessage(msg);
			if(counter1>100)
			{
				pd1.dismiss();
				Intent x = new Intent(getApplicationContext(), Generalinfo.class);
				startActivity(x);
			}
			else
			{
				counter1++;
				pd1.incrementProgressBy(1);
				h1.sendEmptyMessageDelayed(0, 200);
			}
			
		}
    	
    };
    }

    


	public void onClick(View v) 
	{
		
		 Intent i;
		switch (v.getId()) {
	    case R.id.image1:
	    	Toast.makeText(this, "Opening questions", 1000).show();
	    	 i = new Intent("questions");
			startActivity(i);
	      break;
	    case R.id.image5:
	    	pd1.setTitle("Please Wait for few moments . . . ");
			pd1.setMessage("After this, a new quiz will start.");
			pd1.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			h1.sendEmptyMessage(0);
			pd1.show();
	    
	     
	      break;
	    case R.id.image2:
	    	Toast.makeText(this, "Opening Files", 1000).show();
	        i = new Intent("files");
			startActivity(i);
	      break;
	    case R.id.image4:
	    
	    	AlertDialog.Builder ad = new AlertDialog.Builder(this);
			ad.setTitle("Choose the performance");
			ad.setSingleChoiceItems(Performance, -1, new DialogInterface.OnClickListener() 
			{
				
				public void onClick(DialogInterface dialog, int which) 
				{
					 final Intent j;
					Toast t = Toast.makeText(getBaseContext(), "You selected "+Performance[which], 2000);
					t.show();
					if(Performance[which].equals("Your individual Performance"))
					{
						 j = new Intent("performance1");
							startActivity(j);
					}
					else if(Performance[which].equals("Your Overall Performance"))
					{
						 j = new Intent("performance2");
							startActivity(j);
					}
					
					dialog.dismiss();					
				}
			});
	    
			ad.show();
	      break;
	    case R.id.image3:
	    	Toast.makeText(this, "Change your password", 1000).show();
	   	 i = new Intent("password");
			startActivity(i);
	     break;
	    }
	
		
	}
}